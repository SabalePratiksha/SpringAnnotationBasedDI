package com.edu;

public class HumanHeart {
	public  void heartBearting() {
		System.out.println("Heart is Bearting");
	}

	

}
