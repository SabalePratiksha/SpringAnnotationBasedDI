package com.edu;

import org.springframework.beans.factory.annotation.Autowired;

public class HumanBody {
	//field based
	@Autowired           //2nd way to create autowire
	private HumanHeart humanHert;
	
	//setter method   3rd way
	@Autowired 
	public void setHumanHert(HumanHeart humanHert) {
		this.humanHert = humanHert;
	}
	
	//constructor based 
	@Autowired     //1st way
	public HumanBody(HumanHeart humanHert)
	{
		this.humanHert=humanHert;
		
	}
	public void humanMethod() {
		if(humanHert!=null) {
			humanHert.heartBearting();
			
		}
	}



	
	

}
