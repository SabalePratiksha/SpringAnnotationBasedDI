package com.edu;

public class HumanHeart {
	public void HeartBearting() {
		System.out.println("Human is bearting");
		
	}

}
