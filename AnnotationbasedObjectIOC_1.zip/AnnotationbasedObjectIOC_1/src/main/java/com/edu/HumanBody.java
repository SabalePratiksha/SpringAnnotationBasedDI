package com.edu;

import org.springframework.beans.factory.annotation.Autowired;

public class HumanBody {
	// Setter method
	@Autowired
	public void setHumanHeart(HumanHeart humanHeart) {
		this.humanHeart = humanHeart;
	}

	//field based 
	@Autowired
	private HumanHeart humanHeart;
	//constructor based 
      @Autowired
	public HumanBody(HumanHeart humanHeart) {
		super();
		this.humanHeart = humanHeart;
	}
	
	 public void humanmethod() {
		 if(humanHeart !=null) {
			 humanHeart.HeartBearting();
			 
		 }
	 }
	 
	
	

}
