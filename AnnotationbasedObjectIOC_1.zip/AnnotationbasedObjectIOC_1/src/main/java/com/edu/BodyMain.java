package com.edu;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class BodyMain {
	ApplicationContext ctx=new ClassPathXmlApplicationContext("beans.xml");
	HumanBody hb=  (HumanBody) ctx.getBean("humanBody");
	     hb.humanmethod();

}

